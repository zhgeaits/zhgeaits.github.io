package org.zhgeaits.edittexthatekeyboard.surfaceview;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.zhgeaits.edittexthatekeyboard.R;

/**
 * Created by zhgeaits on 2017/6/10.
 */

public class FullSurfaceViewDialogActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.activity_fullscreen_surfaceview_dialog);

        findViewById(R.id.test_edittext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showInputDialog(FullSurfaceViewDialogActivity.this);
            }
        });
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    private void showInputDialog(Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context, R.style.DialogFullscreen);
        Dialog inputDialog = builder.create();

        inputDialog.setCancelable(true);
        inputDialog.setCanceledOnTouchOutside(true);
        inputDialog.show();
        inputDialog.setContentView(R.layout.dialog_input_layout);

        Window window = inputDialog.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        setOnKeyboardHidden(inputDialog);
    }

    private int usableHeightPrevious;
    private void setOnKeyboardHidden(final Dialog inputDialog) {
        final FrameLayout contentView = (FrameLayout) inputDialog.findViewById(android.R.id.content);
        contentView.getChildAt(0).getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                Rect rect = new Rect();
                contentView.getChildAt(0).getWindowVisibleDisplayFrame(rect);
                int usableHeightNow = rect.bottom - rect.top;

                if (usableHeightPrevious == 0) {
                    usableHeightPrevious = usableHeightNow;
                } else if (usableHeightNow != usableHeightPrevious) {
                    int usableHeightSansKeyboard = contentView.getChildAt(0).getRootView().getHeight();
                    int heightDifference = usableHeightSansKeyboard - usableHeightNow;
                    if (heightDifference < (usableHeightSansKeyboard/4)) {
                        inputDialog.dismiss();
                    }
                    usableHeightPrevious = usableHeightNow;
                }
            }
        });
    }
}
