package org.zhgeaits.edittexthatekeyboard;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import org.zhgeaits.edittexthatekeyboard.simple.FullAdjustPanActivity;
import org.zhgeaits.edittexthatekeyboard.simple.FullAdjustResizeActivity;
import org.zhgeaits.edittexthatekeyboard.simple.NoFullAdjustPanActivity;
import org.zhgeaits.edittexthatekeyboard.simple.NoFullAdjustResizeActivity;
import org.zhgeaits.edittexthatekeyboard.simple.inputType.FullInputTypeAdjustPanActivity;
import org.zhgeaits.edittexthatekeyboard.simple.inputType.FullInputTypeAdjustResizeActivity;
import org.zhgeaits.edittexthatekeyboard.simple.inputType.NoFullInputTypeAdjustPanActivity;
import org.zhgeaits.edittexthatekeyboard.simple.inputType.NoFullInputTypeAdjustResizeActivity;
import org.zhgeaits.edittexthatekeyboard.surfaceview.FullSurfaceViewAdjustResizeActivity;
import org.zhgeaits.edittexthatekeyboard.surfaceview.FullSurfaceViewAdjustPanActivity;
import org.zhgeaits.edittexthatekeyboard.surfaceview.FullSurfaceViewDialogActivity;
import org.zhgeaits.edittexthatekeyboard.surfaceview.NoFullSurfaceViewAdjustPanThemeActivity;
import org.zhgeaits.edittexthatekeyboard.surfaceview.NoFullSurfaceViewAdjustPanActivity;
import org.zhgeaits.edittexthatekeyboard.surfaceview.NoFullSurfaceViewAdjustResizeActivity;
import org.zhgeaits.edittexthatekeyboard.surfaceview.inputType.FullSurfaceViewInputTypeAdjustPanActivity;
import org.zhgeaits.edittexthatekeyboard.surfaceview.inputType.FullSurfaceViewInputTypeAdjustResizeActivity;
import org.zhgeaits.edittexthatekeyboard.surfaceview.inputType.NoFullSurfaceViewInputTypeAdjustPanActivity;
import org.zhgeaits.edittexthatekeyboard.surfaceview.inputType.NoFullSurfaceViewInputTypeAdjustPanTheme2Activity;
import org.zhgeaits.edittexthatekeyboard.surfaceview.inputType.NoFullSurfaceViewInputTypeAdjustPanThemeActivity;
import org.zhgeaits.edittexthatekeyboard.surfaceview.inputType.NoFullSurfaceViewInputTypeAdjustResizeActivity;

public class MainActivity extends AppCompatActivity {

    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;

        //simple
        findViewById(R.id.test1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, NoFullAdjustPanActivity.class);
                mContext.startActivity(intent);
            }
        });

        findViewById(R.id.test2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, NoFullAdjustResizeActivity.class);
                mContext.startActivity(intent);
            }
        });

        findViewById(R.id.test3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, FullAdjustPanActivity.class);
                mContext.startActivity(intent);
            }
        });

        findViewById(R.id.test4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, FullAdjustResizeActivity.class);
                mContext.startActivity(intent);
            }
        });



        //surfaceview
        findViewById(R.id.test5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, NoFullSurfaceViewAdjustPanActivity.class);
                mContext.startActivity(intent);
            }
        });

        findViewById(R.id.test51).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, NoFullSurfaceViewAdjustPanThemeActivity.class);
                mContext.startActivity(intent);
            }
        });

        findViewById(R.id.test6).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, NoFullSurfaceViewAdjustResizeActivity.class);
                mContext.startActivity(intent);
            }
        });

        findViewById(R.id.test7).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, FullSurfaceViewAdjustPanActivity.class);
                mContext.startActivity(intent);
            }
        });

        findViewById(R.id.test8).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, FullSurfaceViewAdjustResizeActivity.class);
                mContext.startActivity(intent);
            }
        });


        //simple + inputType
        findViewById(R.id.test9).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, NoFullInputTypeAdjustPanActivity.class);
                mContext.startActivity(intent);
            }
        });

        findViewById(R.id.test10).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, NoFullInputTypeAdjustResizeActivity.class);
                mContext.startActivity(intent);
            }
        });

        findViewById(R.id.test11).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, FullInputTypeAdjustPanActivity.class);
                mContext.startActivity(intent);
            }
        });

        findViewById(R.id.test12).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, FullInputTypeAdjustResizeActivity.class);
                mContext.startActivity(intent);
            }
        });

        //surfaceview + inputtype

        findViewById(R.id.test13).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, NoFullSurfaceViewInputTypeAdjustPanActivity.class);
                mContext.startActivity(intent);
            }
        });

        findViewById(R.id.test131).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, NoFullSurfaceViewInputTypeAdjustPanThemeActivity.class);
                mContext.startActivity(intent);
            }
        });

        findViewById(R.id.test132).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, NoFullSurfaceViewInputTypeAdjustPanTheme2Activity.class);
                mContext.startActivity(intent);
            }
        });

        findViewById(R.id.test14).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, NoFullSurfaceViewInputTypeAdjustResizeActivity.class);
                mContext.startActivity(intent);
            }
        });

        findViewById(R.id.test15).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, FullSurfaceViewInputTypeAdjustPanActivity.class);
                mContext.startActivity(intent);
            }
        });

        findViewById(R.id.test16).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, FullSurfaceViewInputTypeAdjustResizeActivity.class);
                mContext.startActivity(intent);
            }
        });

        //dialog
        findViewById(R.id.test17).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, FullSurfaceViewDialogActivity.class);
                mContext.startActivity(intent);
            }
        });
    }
}
