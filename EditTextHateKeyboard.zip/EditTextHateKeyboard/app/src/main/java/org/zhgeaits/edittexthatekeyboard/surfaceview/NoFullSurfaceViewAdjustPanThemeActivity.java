package org.zhgeaits.edittexthatekeyboard.surfaceview;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;

import org.zhgeaits.edittexthatekeyboard.R;

/**
 * Created by zhgeaits on 2017/6/10.
 */

public class NoFullSurfaceViewAdjustPanThemeActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nofullscreen_surfaceview_adjustpan);
    }
}
